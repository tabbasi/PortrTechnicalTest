﻿using System;
using System.Collections.Generic;
using System.Configuration;

namespace SoftwareEngineerTest
{
    class Program
    {
        static void Main(string[] args)
        {

           
           // end boound in configuration for now i just configured it for 20 it can be any positive number .
           int  endNumber = Convert.ToInt32(ConfigurationManager.AppSettings.Get("endWith"));
            // Getting 3 from configuration file . 
            int three = Convert.ToInt32(ConfigurationManager.AppSettings.Get("NumberOne"));
           // int five = Convert.ToInt32(ConfigurationManager.AppSettings.Get("NumberTwo"));
           
            FizBuzzTest(endNumber , three );
            Console.ReadKey();
        }
        /// <summary>
        ///  This funcation takes three parameters from configuration file .
        /// </summary>
        /// <param name="endWith"></param>
        /// <param name="num1"></param>
        
        public static void FizBuzzTest(int endWith , int num1 )
        {
            int integercounter = 0;
            int counter = 0;
            int fizCount = 0;
            int buzzCount = 0;
            int fizzbuzzCount = 0;
            int luckyCount = 0;
            string str = "";
         
            for (int number=1; number <= endWith; number ++)
            {
               
                
               
                string checkThree = Convert.ToString(number);

                if (checkThree.Contains("3") == true)
                {
                    str += "Lucky";
                    counter++;
                    luckyCount++;
                }

                else if (number % 15 == 0)
                {
                    str += "Fizzbuzz";
                    counter++;
                    fizzbuzzCount++;
                }
                else if (number % 5 == 0)
                {
                    str += "Buzz";
                    counter++;
                    buzzCount++;
                }
                else if  (number % 3 == 0)
                {
                    str += "Fizz";
                    counter++;
                    fizCount++;
                }
              
                else
                {
                    str += number.ToString();
                    
                    integercounter++;
                }
                //if (str.Length == 0)
                //{
                //    str = number.ToString();
                //}

                
            }
            Console.WriteLine(str +   " Fizz:" + fizCount + " buzz:" + buzzCount+ "fizBuz:" + fizzbuzzCount + "Lucky:" + luckyCount + "integer: " + integercounter );

        }
    }
}
//+ " buzz:" + buzzCount +  "fizzbuzz:" + fizzbuzzCount